<?php
/* @var $this NoticiaController */
/* @var $model Noticia */

$this->breadcrumbs=array(
	'Noticias'=>array('index'),
	$model->idnoticia,
);
/*

$this->menu=array(
	array('label'=>'List Noticia', 'url'=>array('index')),
	array('label'=>'Create Noticia', 'url'=>array('create')),
	array('label'=>'Update Noticia', 'url'=>array('update', 'id'=>$model->idnoticia)),
	array('label'=>'Delete Noticia', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->idnoticia),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Noticia', 'url'=>array('admin')),
);
*/
?>

<h1>Lista de  Noticia #<?php echo $model->idnoticia; ?></h1>

<?php 
/*
	$echo= 'hola';
	$this->widget('bootstrap.widgets.TbDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'idnoticia',
		'titulonoticia',
		'Fechapublinoticiascol',
		'fechanoticias',
		'autornoticia',
		//'resumen',
		//'descripnoticia',
		'categoria.categoriaDes',
	),
)); 
*/
?>

<?php 

//para poder cargar solo los datos mediante un echo
//echo $model->resumen;
//$echo= 'hola';
	$this->widget('bootstrap.widgets.TbDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		//'idnoticia',
		'titulonoticia',
		'Fechapublinoticiascol',
		'fechanoticias',
		'autornoticia',
		'categoria.categoriaDes',
	),
));

/*
$this->widget(
    'bootstrap.widgets.TbBox',
    array(
        'title' => $model->titulonoticia,
        'headerIcon' => 'icon-home',
        'content' => 'My Basic Content (you can use renderPartial here too :))'
    )
);
*/
 ?>

<?php echo $model->resumen; ?>


<!-- Stack the columns on mobile by making one full-width and the other half-width -->
<div class="row">
  <div class="col-xs-12 col-md-8"><?php echo $model->resumen; ?></div>
  <div class="col-xs-6 col-md-4"><?php echo $model->resumen; ?></div>
</div>


<div class="col-xs-12 col-sm-9">
<p class="pull-right visible-xs">
<button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
</p>
<div class="jumbotron">
<h1>Hello, world!</h1>
<p>This is an example to show the potential of an offcanvas layout pattern in Bootstrap. Try some responsive-range viewport sizes to see it in action.</p>
</div>

<div class="col-xs-6 col-lg-4">
<h2>Heading</h2>
<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
<p><a class="btn btn-default" href="#" role="button">View details »</a></p>
</div>

</div>
